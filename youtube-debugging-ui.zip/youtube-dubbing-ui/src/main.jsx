import React from 'react';
import { createRoot } from 'react-dom/client';
import YoutubeDubbingUI from './YoutubeDubbingUI.jsx';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <YoutubeDubbingUI />
  </React.StrictMode>
);
